// 모든 페이지 공통 navbar , footer

// 공통 메뉴 정의
// href : 이동할 경로 / label : 표시 글자 / admin : 관리자 전용 여부
const NAV_ITEMS = [
    { href: "/static/index.html",   label: "지도" },
    { href: "/static/predict.html", label: "예측하기" },
    { href: "/static/mypage.html",  label: "내 예약" },
    { href: "/static/admin.html",   label: "관리자", admin: true },  // 관리자만 노출
];

// navbar HTML 문자열 생성
function renderNavbar() {
    const path = window.location.pathname; // 현재 페이지 경로, http://127.0.0.1:8000/static/index.html
    const admin = (typeof isAdmin === "function") && isAdmin(); // isAdmin이 함수면 isAdmin() 함수 호출
    // 관리자 여부에 따라 메뉴 목록을 필터링, 일반 사용자와 관리자 전용은 관리자만
    const menuHtml = NAV_ITEMS.filter(item => !item.admin || admin).map(item => {
        // 현재 페이지면 active 클래스 부여, /static/index.html,
        const active = path.endsWith(item.href.split("/").pop()) ? "active" : "";
        return `<li class="nav-item">
                    <a class="nav-link ${active}" href="${item.href}">${item.label}</a>
                </li>`;
    }).join("");
    return `
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
      <div class="container">
        <a class="navbar-brand  fw-bold" href="/static/index.html"><i class="bi bi-p-square-fill"></i> 한강공원 주차 예측</a>
        <!--  햄버거 버튼    -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMenu" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMenu">
          <ul class="navbar-nav me-auto">
            ${menuHtml}
          </ul>
           <div class="d-flex gap-2 align-items-center"  id="authButtons">
                 <!-- 로그인 상태: 사용자 이름 표시 -->
                <span class="navbar-text d-none text-light small" id="userNameDisplay"></span>
                <!-- 로그인 상태: 로그아웃 버튼 -->
                <button class="btn btn-outline-light btn-sm d-none" id="logoutBtn">로그아웃</button>
                <!-- 로그인 버튼: 로그인 모달을 여는 트리거 -->
                <button type="button" class="btn btn-outline-light  btn-sm"
                        id="loginBtn" data-bs-toggle="modal" data-bs-target="#authModal">로그인</button>
            </div>
        </div>
      </div>
    </nav>`;
}
// footer HTML 문자열 생성
function renderFooter() {
    const year = new Date().getFullYear();
    return `
        <footer  class="bg-light border-top mt-5 py-3">
            <div class="container text-center text-muted small">
                한강공원 주차장 예측 서비스 | 데이터: 서울 열린데이터광장 | &copy; ${year}
            </div>
        </footer>`;
}
// navbar 로그인 상태 반영
//  Navbar 인증 상태 전환
function updateNavbar() {
    const loginBtn        = document.querySelector("#loginBtn");
    const logoutBtn       = document.querySelector("#logoutBtn");
    const userNameDisplay = document.querySelector("#userNameDisplay");
    // navbar가 아직 안 그려졌으면 중단(방어 코드)
    if (!loginBtn || !logoutBtn || !userNameDisplay) return;

    if(isLoggedIn()) { // 로그인 상태 처리
        loginBtn.classList.add("d-none");           // 로그인 버튼 숨김
        logoutBtn.classList.remove("d-none");       // 로그아웃 버튼 표시
        userNameDisplay.classList.remove("d-none"); // 이름 표시
        userNameDisplay.textContent = `${getUserName()}님`;
    } else { // 비로그인 상태 처리
        loginBtn.classList.remove("d-none");     // 로그인 버튼 표시
        logoutBtn.classList.add("d-none");       // 로그아웃 버튼 숨김
        userNameDisplay.classList.add("d-none"); // 이름 숨김
        userNameDisplay.textContent = "";        // 텍스트 초기화
    }
}

// 로그아웃 처리 함수
function handleLogout() {
    removeToken(); // api.js
    localStorage.removeItem("user_name");
    updateNavbar(); // Navbar를 "로그인 버튼" 상태로 전환
    showToast("로그아웃 되었습니다.", "warning");
    window.location.href = "/static/index.html"; // 로그아웃 후 메인 페이지로 이동 (관리자 페이지에 남지 않도록)
}

//메뉴(관리자 링크 포함)를 새 로그인 상태로 다시 그림
function refreshNavbar() {
    const navSlot = document.querySelector("#navbar-placeholder");
    if (!navSlot) return;
    navSlot.innerHTML = renderNavbar();
    updateNavbar(); // 로그인,로그아웃 버튼 상태 반영
    // innerHTML을 새로 넣으면 기존 이벤트 연결이 사라지므로 다시 연결
    const logoutBtn = document.querySelector("#logoutBtn");
    if (logoutBtn) logoutBtn.addEventListener("click", handleLogout);
}

// 페이지 로드 시: navbar/footer 삽입 → 상태 반영 → 이벤트 연결
document.addEventListener("DOMContentLoaded", () => {
    const footSlot = document.querySelector("#footer-placeholder");
    if (footSlot) footSlot.innerHTML = renderFooter();

    refreshNavbar(); // navbar 그리기 + 로그인 상태 반영 + 로그아웃 버튼 연결
});